# Реализуем скрипт проверки данных элементов в списке
type_list = [1, 3.56, 4, "John", "age", 66, 36]
for i in type_list:
    print(f"{i} is {type(i)}")