# Пользаветель вводит число, которое добавляется в список
# Рейтинг указывается по убывающей
reit_list = [7, 5, 3, 3, 2]
reit_list = reit_list
print(f"Рейтинг - {reit_list}")
digit = int(input("Введите число (404 - выход) "))
while digit != 404:
    for el in range(len(reit_list)):
        if reit_list[el] == digit:
            reit_list.insert(el + 1, digit)
            break
        elif reit_list[0] < digit:
            reit_list.insert(0, digit)
        elif reit_list[-1] > digit:
            reit_list.append(digit)
        elif reit_list[el] > digit and reit_list[el + 1] < digit:
            reit_list.insert(el + 1, digit)
    print(f"текущий список - {reit_list}")
    digit = int(input("Введите число "))
