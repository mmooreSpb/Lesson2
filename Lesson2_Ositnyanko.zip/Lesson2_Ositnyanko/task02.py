# Задание 2
# Запрашиваем список неопределенной длинны
# Реализуем обмен значений соседних элементов
userList = [int(i)
            for i in input('Введите целые числа через пробел ').split()]
if len(userList) % 2 == 0:
    i = 0
    while i < len(userList):
        el = userList[i]
        userList[i] = userList[i + 1]
        userList[i + 1] = el
        i += 2
else:
    i = 0
while i < len(userList) - 1:
    el = userList[i]
    userList[i] = userList[i + 1]
    userList[i + 1] = el
    i += 2

print(userList)
